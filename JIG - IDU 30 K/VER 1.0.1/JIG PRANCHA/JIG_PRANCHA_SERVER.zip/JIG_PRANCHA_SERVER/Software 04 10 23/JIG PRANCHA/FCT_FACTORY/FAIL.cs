﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FCT_FACTORY
{
    public partial class FAIL : Form
    {
        Form1 instanciaDoFormMain;
        public FAIL(Form1 formMain)
        {
            instanciaDoFormMain = formMain;
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterParent;
        }

        private void FAIL_Load(object sender, EventArgs e)
        {
            textBox1.Text = instanciaDoFormMain.msgFail;
        }
    }
}
