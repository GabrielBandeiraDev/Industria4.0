﻿using System;
using System.Data.OleDb;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;


//1.0.27 - > Condição criada= SendKeys.SendWait("{ENTER}"); Foi atribuido nos metedos FIM, TIMER1 e FORM_SHOW

//1.0.28 - > O metodo endKeys.SendWait("{ENTER}"); foi aplicado, porém, após o click, a grid era limpada(o usuario não conseguia ler os valores) e o form do SERIAL não estava em uma boa posição.
//Location = new Point(740, 710); -> para posicianar o form da serial
//O clearDataGrid foi retirado do metodo iniTest e colocado no click do botão Inciar


//1.0.29 -> Remoção dos testes dos leds teste 5 e 8


namespace FCT_FACTORY
{
    public partial class Form1 : Form
    {
        MouseClass Mouse = new MouseClass();
        Connections _connection = new Connections();
        String linha = "";
        IniFile _myIni;
        public Bitmap bitmap;
        public Graphics graphics;
        public System.Drawing.Rectangle rect;
        public Bitmap cropped;

        string message = "";
        public string recebeFormSerial;
        string channel = "", snum = "", addr = "", snum2 = "";
        private EAN13 ean13 = new EAN13();
        double temp_ini, temp_fim;
        double power_max1, power_max2, current_max1, current_max2, temp_max1, temp_max2;
        double temp1Sensor, temp2Sensor, temp3Sensor, temp4Sensor;
        string led1, led2;
        //array usado para percorrer os testes, necessidade quando foi necessario pular testes
        int[] teste127_220 = { 0, 1, 2, 4, 6, 7, 9, 10, 11 };
        bool msgDeErro = false;
        public bool instanciaEmerg = false;
        bool inicio2, fail2;
        int indexTest2;
        int contaFalhaTP = 0;
        int linhasTotal = 0;
        bool linux = false;
        string cmdAT = "";
        string caminho = System.Windows.Forms.Application.StartupPath.ToString() + "/config.txt";
        string mac;
        string system;
        string executar;
        public bool login = false;
        string testStatusReport = "";
        string IP;
        int PORTA;
        int SN_LEN = 0;
        string testStatus = "FAIL";
        string testShortCurt = "FAIL";
        string test_100vac_4a = "NULL", test_efficiency = "NULL", test_ripple = "NULL", test_overload = "NULL", test_powerOff = "NULL", test_high_vac4a = "NULL", test_high_vac75a = "NULL", test_high_vac0a = "NULL", test_discharger = "NULL", comandoTest = "NULL";
        string GAC = "";
        string GVT = "";
        string GAP = "";
        string GEF = "";
        public string modeloSelecionado = "";
        string[,] TESTS = new string[3, 20];
        double[] limits = new double[21];
        double[] limitsMin = new double[21];
        double[] limitsMax = new double[21];
        bool trackingTest;
        string _mode;
        string strcon = "";
        public string UserName = "";
        string rangerVoltage = "23.76V ~ 25.23V";
        string rangerCurrent = "3.325 ~ 3.675A";
        string directory = "";
        int contador = 0;
        int contaFalha = 1;
        Boolean inicio = false;
        Boolean fail = false;
        bool reteste = false;
        bool[] TEST = new bool[21];
        bool[] TEST2 = new bool[21];
        bool[] RES_TEST = new bool[21];
        bool[] RES_TEST2 = new bool[21];
        bool getSerial = true;
        string statusTest = "";
        string statusTest2 = "";
        int indexTest = 0;
        string cicliTimerStr = "NULL";
        int ccc = 0;
        string[] msgStatus = new string[12];
        float min, max;
        bool testRead = false;
        int ms = 0;
        string[] str;
        string validaTeste;
        bool testPass = true;
        int lineReteste = 0;
        string rxData2;

        public Form1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void CreateEan13()
        {
            ean13.CountryCode = "00";
            ean13.ManufacturerCode = "00";
            ean13.ProductCode = "12345";
        }

        //*************************************************************************************
        System.Diagnostics.Process cmd = new System.Diagnostics.Process();
        System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
        /************************************ DATA BASE  **************************/

        OleDbConnection conexao;
        OleDbCommand dbcmd;

        private void cmdExec(string comando)
        {
            startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = "/C " + comando;
            cmd.StartInfo = startInfo;
            cmd.Start();
            cmd.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (Directory.Exists("/home"))
            {
                string[] lines = System.IO.File.ReadAllLines(caminho);

                foreach (string line in lines)
                {
                    // Use a tab to indent each line of the file.
                    string[] str = line.Split('=');
                    if (str[0] == "port") { serialPort1.PortName = str[1]; }
                    if (str[0] == "port2") { serialPort2.PortName = str[1]; }
                    if (str[0] == "speed") { timer1.Interval = int.Parse(str[1]); }
                    if (str[0] == "baudRate") { serialPort1.BaudRate = int.Parse(str[1]); }
                    if (str[0] == "baudRate2") { serialPort2.BaudRate = int.Parse(str[1]); }
                    if (str[0] == "script") { caminho = str[1]; }

                    StreamReader sr = new StreamReader(caminho);
                    richTextBox1.Text = sr.ReadToEnd();
                    sr.Close();
                }

                this.Text += " Lin";
                linux = true;
                checkBox1.Enabled = false;
                textBox3.Enabled = false;

            }
            else
            {
                IniFile _myIni = new IniFile(System.Windows.Forms.Application.StartupPath.ToString() + "\\Setup.ini");
                strcon = _myIni.Read("strCon", "dataBase");
                directory = _myIni.Read("dirExport", "dataBase");

                IP = _myIni.Read("IP", "dataBase");
                PORTA = int.Parse(_myIni.Read("PORTA", "dataBase"));
                SN_LEN = int.Parse(_myIni.Read("SN_LEN", "dataBase"));

                serialPort1.PortName = _myIni.Read("com", "Port");
                serialPort1.BaudRate = int.Parse(_myIni.Read("baudRate", "Port"));

                trackingTest = bool.Parse(_myIni.Read("track", "dataBase"));
                _mode = _myIni.Read("mode", "dataBase");

                serialPort2.PortName = _myIni.Read("com2", "Port");
                serialPort2.BaudRate = int.Parse(_myIni.Read("baudRate2", "Port"));
                timer1.Interval = int.Parse(_myIni.Read("Speed", "setSpeed"));

                string cm = _myIni.Read("SCRIPT", "dataBase");
                string posto = _myIni.Read("ID", "dataBase");

                //txtID.Text = "TEST " + posto;
                //StreamReader sr = new StreamReader(cm);
                //richTextBox1.Text = sr.ReadToEnd();
                //sr.Close();

                //limits[0] = double.Parse(_myIni.Read("testShort", "dataBase"));
                limits[1] = double.Parse(_myIni.Read("corrente_min1", "dataBase"));
                current_max1 = double.Parse(_myIni.Read("corrente_max1", "dataBase"));
                limits[2] = double.Parse(_myIni.Read("potencia_min1", "dataBase"));
                power_max1 = double.Parse(_myIni.Read("potencia_max1", "dataBase"));

                //limits[3] = double.Parse(_myIni.Read("temp1_min", "dataBase"));
                //temp_max1 = double.Parse(_myIni.Read("temp1_max", "dataBase"));

                limits[5] = double.Parse(_myIni.Read("leds1", "dataBase"));

                led1 = _myIni.Read("leds1", "dataBase");

                limits[6] = double.Parse(_myIni.Read("corrente_min2", "dataBase"));
                current_max2 = double.Parse(_myIni.Read("corrente_max2", "dataBase"));
                limits[7] = double.Parse(_myIni.Read("potencia_min2", "dataBase"));
                power_max2 = double.Parse(_myIni.Read("potencia_max2", "dataBase"));
                limits[8] = double.Parse(_myIni.Read("leds2", "dataBase"));

                led2 = _myIni.Read("leds2", "dataBase");

                limits[9] = double.Parse(_myIni.Read("temp2_min", "dataBase"));
                temp_max2 = double.Parse(_myIni.Read("temp2_max", "dataBase"));

                this.Text += " Win";

                txtID.Text = serialPort1.PortName;

                if (trackingTest)
                {
                    this.Visible = false;
                    UserId user = new UserId(this);
                    user.ShowDialog();
                    login = true;

                    if (!login)
                    {
                        this.Close();
                    }

                    this.Visible = true;
                }
            }

            linhasTotal = 8;
            for (int i = 0; i < linhasTotal; i++)
            {
                dataGridView1.Rows.Add();
            }

            dataGridView1.Rows[0].Cells[0].Value = "LIGA PRODUTO | 127V";

            dataGridView1.Rows[1].Cells[0].Value = "CORRENTE 1";
            dataGridView1.Rows[1].Cells[2].Value = limits[1] + " a " + current_max1 + " (Amp)";

            dataGridView1.Rows[2].Cells[0].Value = "POTÊNCIA 1";
            dataGridView1.Rows[2].Cells[2].Value = limits[2] + " a " + power_max1 + " (Watts)";

            //dataGridView1.Rows[3].Cells[0].Value = "TEMPERATURA 1";
            //dataGridView1.Rows[3].Cells[2].Value = limits[3] + "°C" + " a " + temp_max1 + "°C";

            dataGridView1.Rows[3].Cells[0].Value = "CHAVEIA PRODUTO | 220V";

            //dataGridView1.Rows[5].Cells[0].Value = "LEDS +";
            //dataGridView1.Rows[5].Cells[2].Value = led1;

            dataGridView1.Rows[4].Cells[2].Value = limits[6] + " a " + current_max2 + " (Amp)";
            dataGridView1.Rows[4].Cells[0].Value = "CORRENTE 2";

            dataGridView1.Rows[5].Cells[2].Value = limits[7] + " a " + power_max2 + " (Watts)";
            dataGridView1.Rows[5].Cells[0].Value = "POTÊNCIA 2";

            //dataGridView1.Rows[8].Cells[0].Value = "LEDS -";
            //dataGridView1.Rows[8].Cells[2].Value = led2;

            dataGridView1.Rows[6].Cells[0].Value = "TEMPERATURA 2";
            dataGridView1.Rows[6].Cells[2].Value = limits[9] + "°C" + " a " + temp_max2 + "°C";

            dataGridView1.Rows[7].Cells[0].Value = "DESLIGAR";
            dataGridView1.Rows[7].Cells[2].Value = limits[10];

            for (int i = 0; i < 3; i++)
            {

                for (int j = 0; j < 10; j++)
                {

                    TESTS[i, j] = "NULL";
                }
            }

            defineLimitsMinMax();
            textBox4.Text = UserName;
            richTextBox1.Enabled = false;
            button1.Focus();
            textBox5.Text = "PRANCHA";

            try
            {
                if (!serialPort1.IsOpen)
                {
                    serialPort1.Open();
                    timer3.Start();
                }
            }
            catch (Exception)
            {
                fail = true;
                textBox6.BackColor = Color.Red;
                textBox6.Text = "SERIAL PORT FAIL";
                textBox6.Visible = true;
            }
        }

        private void delay(int ms)
        {
            DateTime dateTimeTarget = DateTime.Now.AddMilliseconds(ms);
            while (DateTime.Now < dateTimeTarget)
            {
                System.Windows.Forms.Application.DoEvents();
            }
        }

        private void clearDataGrid1()
        {
            for (int i = 0; i < 9; i++)
            {
                dataGridView1.Rows[i].Cells[1].Value = "";
                dataGridView1.Rows[i].Cells[3].Value = "";
                dataGridView1.Rows[i].Cells[4].Value = "";
            }
        }

        private void clearDataGrid2()
        {
            for (int i = 0; i < 17; i++)
            {
                //
            }
        }

        private void initTest1()
        {
            //clearDataGrid1();
            indexTest = 0;
            timer1.Stop();
            rxData = "";
            getSerial = true;
            inicio = false;
            fail = false;
            indexTest = 0;
            dataGridView1.Rows[indexTest].Selected = false;
            richTextBox2.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
            inicioTeste();
        }

        Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        public void ConnectServer(Int32 port, string ips)
        {
            IPAddress host = IPAddress.Parse(ips);//  
            IPEndPoint ipendpoint = new IPEndPoint(host, port); // assign host and port                                                               
            if (!socket.Connected)
            {
                try
                {
                    socket.Connect(ipendpoint);
                    this.Text += " (Connected)";
                }
                catch (SocketException e)
                {
                    this.Text += " (Offline)";
                    MessageBox.Show(e.Message);
                    socket.Close();
                    return;
                }
            }
            else
            {
                socket.Close();
                this.Text += " ( Offline)";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            initTest1();
            clearDataGrid1();

        }

        private void defineLimitsMinMax()
        {
            //curto
            limitsMin[0] = 50;
            limitsMax[0] = 250;

            //corrente 1
            limitsMin[1] = limits[1];
            limitsMax[1] = current_max1;

            //potencia 1
            limitsMin[2] = limits[2];
            limitsMax[2] = power_max1;

            //temp1			
            limitsMin[3] = limits[3];
            limitsMax[3] = temp_max1;

            //chave 220
            limitsMin[4] = 0;
            limitsMax[4] = 250;

            //leds1
            limitsMin[5] = limits[5];
            limitsMax[5] = limits[5];

            //corrente 2
            limitsMin[6] = limits[6];
            limitsMax[6] = current_max2;

            //potencia 2
            limitsMin[7] = limits[7];
            limitsMax[7] = power_max2;

            //leds2
            limitsMin[8] = limits[8];
            limitsMax[8] = limits[8];

            //temp2
            limitsMin[9] = limits[9];
            limitsMax[9] = temp_max2;

            //desligar
            limitsMin[10] = 0;
            limitsMax[10] = 5;
        }

        bool statusPassOrFail = false;
        private bool checkTest(int position, double value, string valor)
        {
            value = value / 100;

            Console.WriteLine("-------------------------");
            Console.WriteLine(position);
            Console.WriteLine(limitsMin[position]);
            Console.WriteLine(value);
            Console.WriteLine(limitsMax[position]);
            Console.WriteLine(valor);
            Console.WriteLine("-------------------------");

            if (value >= limitsMin[position] && value <= limitsMax[position])
            {
                statusPassOrFail = true;
            }
            else
            {
                statusPassOrFail = false;
            }

            //if (position == 5)
            //{
            //    if (led1 == valor)
            //    {
            //        statusPassOrFail = true;
            //    }
            //}

            //if (position == 8)
            //{
            //    if (led2 == valor)
            //    {
            //        statusPassOrFail = true;
            //    }
            //}

            return statusPassOrFail;

        }

        int valorRecebido = 0;
        bool resultadoDoCheck = false;

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (fail == false)
            {
                if (inicio == false)
                {
                    //inicia temporizador de teste
                    initTimer();
                    inicio = true;
                }

                if (getSerial)
                {
                    TEST[0] = true;

                    serialPort1.Write("0");

                    getSerial = false;

                    textBox6.Visible = true;
                    textBox6.Text = "TESTANDO...";
                    textBox6.BackColor = Color.Yellow;
                }

                if (TEST[indexTest])
                {
                    dataGridView1.Rows[indexTest].Selected = true;
                    dataGridView1.Rows[indexTest].Cells[4].Value = "TESTANDO...";
                    TEST[indexTest] = false;
                    RES_TEST[indexTest] = true;
                }

                if (RES_TEST[indexTest])
                {
                    Console.WriteLine(rxData);
                    textBox2.Text = rxData;


                    if (textBox2.Text.Contains("X"))
                    {
                        string[] dados = textBox2.Text.Split(';');

                        Console.WriteLine(dados);

                        // try
                        //{
                        //    if (indexTest == 3)
                        //    {
                        //        temp1Sensor = double.Parse(dados[1]);
                        //        temp2Sensor = double.Parse(dados[2]);

                        //    }
                        //}
                        //catch (Exception)
                        //{

                        //    if (!msgDeErro)
                        //    {
                        //        resultadoDoCheck = false;
                        //    }


                        //}

                        try
                        {
                            if (indexTest == 6)
                            {
                                temp3Sensor = double.Parse(dados[1]);
                                temp4Sensor = double.Parse(dados[2]);

                                if (temp1Sensor < temp3Sensor && temp2Sensor < temp4Sensor)
                                {
                                    resultadoDoCheck = true;

                                }
                                else
                                {
                                    resultadoDoCheck = false;
                                }
                            }
                        }
                        catch (Exception)
                        {
                            if (!msgDeErro)
                            {
                                resultadoDoCheck = false;
                            }
                        }

                        resultadoDoCheck = checkTest(teste127_220[indexTest], double.Parse(dados[2]), dados[2]);
                        if (resultadoDoCheck)
                        {
                            ////TESTE CURTO CIRCUITO
                            //if (indexTest == 0 || indexTest == 8)
                            //{
                            //    TESTS[1, indexTest] = "APROVADO";
                            //    temp_ini = double.Parse(dados[2]);
                            //    temp_ini = temp_ini / 100;
                            //}
                            //else if (indexTest == 2 || indexTest == 8) { TESTS[1, indexTest] = dados[2]; }   //TEST EFICIENCIA 100 e 230AC
                            //else
                            //{
                            //    TESTS[1, indexTest] = dados[1] + "VAC, " + dados[2] + "VDC, " + dados[3] + "A";
                            //}

                            statusTest = "OK";
                            dataGridView1.Rows[indexTest].Cells[1].Value = dados[1];
                            dataGridView1.Rows[indexTest].Cells[3].Value = dados[2];
                            dataGridView1.Rows[indexTest].Cells[4].Value = statusTest;

                            dataGridView1.DefaultCellStyle.SelectionForeColor = Color.Green;
                            dataGridView1.Rows[indexTest].Selected = false;
                            indexTest++;
                            TEST[indexTest] = true;
                            dados[0] = "";

                            RES_TEST[indexTest] = false;
                            rxData = "";
                            textBox2.Text = "";

                            serialPort1.Write(teste127_220[indexTest].ToString());
                        }
                        else
                        {
                            ////TESTE CURTO CIRCUITO
                            //if (indexTest == 0) { TESTS[1, indexTest] = "FALHA"; }
                            //else if (indexTest == 2 || indexTest == 8) { TESTS[1, indexTest] = dados[2]; }   //TEST EFICIENCIA 100 e 230AC
                            //else
                            //{
                            //    TESTS[1, indexTest] = dados[1] + "VAC, " + dados[2] + "VDC, " + dados[3] + "A";
                            //}

                            dataGridView1.DefaultCellStyle.SelectionForeColor = Color.Red;
                            textBox6.Visible = true;
                            textBox6.Text = "FALHA";
                            textBox6.BackColor = Color.Red;
                            timer1.Stop();
                            inicio = false;

                            statusTest = "FALHA";
                            dataGridView1.Rows[indexTest].Cells[1].Value = dados[1];
                            dataGridView1.Rows[indexTest].Cells[3].Value = dados[2];
                            dataGridView1.Rows[indexTest].Cells[4].Value = statusTest;



                            if (trackingTest)
                            {
                                if (_mode == "txt")
                                {
                                    createLogs(1);
                                }
                            }

                            //  SendKeys.SendWait("{ENTER}");
                        }
                    }
                }

                if (indexTest > linhasTotal - 1)
                {
                    serialPort1.Write("10");
                    timer1.Stop();
                    endTimer();
                    textBox6.Visible = true;
                    textBox6.Text = "APROVADO - " + fim;
                    textBox6.BackColor = Color.GreenYellow;
                    FIM();
                }
            }
        }

        int contaTeste = 1;
        public void parametro(String comando)
        {
            if (comando.Contains("cmdFIM"))
            {
                FIM();
            }

            else if (comando.Contains("cmdMSG"))
            {
                lineReteste = contador;
                Console.WriteLine("LineReteste: " + lineReteste);

                textBox1.ForeColor = Color.Yellow;
                textBox2.Text = "";
                int l = comando.Length;
                comando = comando.Substring(6, l - 6);

                if (!reteste)
                {
                    textBox1.Text = comando;
                }
                else
                {
                    textBox1.Text = comando + " [RETESTE] " + "[" + contaFalha + "]";
                }


                if (testPass == false)
                {
                    testPass = true;
                    richTextBox2.Text += contaTeste.ToString() + " - " + validaTeste + "\t[PASS]\r\n";
                    contaTeste++;
                }

                validaTeste = comando;
                testPass = false;

            }

            //LIGA PORTA DIGITAL----------------------------
            else if (comando.Substring(0, 2) == "LD")
            {
                textBox2.Text = "";
                serialPort1.WriteLine(comando);
            }

            //DESLIGA PORTA DIGITAL----------------------------
            else if (comando.Substring(0, 2) == "DD")
            {
                textBox2.Text = "";
                serialPort1.WriteLine(comando);
            }

            //calibração----------------------------
            else if (comando.Substring(0, 6) == "cmdCHW")
            {
                if (!serialPort2.IsOpen) { serialPort2.Open(); }
                textBox2.Text = "";
                serialPort2.WriteLine("CKW");

                DateTime dateTimeTarget = DateTime.Now.AddMilliseconds(5000);
                while (DateTime.Now < dateTimeTarget)
                {
                    System.Windows.Forms.Application.DoEvents();
                }
                //MessageBox.Show("Aguarde...");
                if (textBox2.Text.Contains("FALHA"))
                {
                    textBox1.Text = "FALHA NO TESTE DE CALIBRAÇÃO";
                    falha();
                }
            }

            //ativa escritas na tela //send commander
            else if (comando.Substring(0, 6) == "cmdSCM")
            {
                if (!serialPort2.IsOpen) { serialPort2.Open(); }
                string send = comando.Substring(7, comando.Length - 7);
                serialPort2.WriteLine(send);
                //textBox2.Text = send;
            }

            //procura uma informação no testbox
            else if (comando.Substring(0, 6) == "cmdFND")
            {
                if (!serialPort2.IsOpen) { serialPort2.Open(); }
                string find = comando.Substring(7, comando.Length - 7);

                //MessageBox.Show("Aguarde...");
                if (!textBox2.Text.Contains(find))
                {
                    textBox1.Text = "FALHA NOS PARAMETROS";
                    falha();
                }
            }

            //ENVIA COMANDO AT----------------------------
            else if (comando.Substring(0, 5) == "cmdAT")
            {
                cmdAT = comando;
                textBox2.Text = "";
                timer1.Stop();
                //cmdAT AT+LEDR,OK
                if (!serialPort2.IsOpen) { serialPort2.Open(); }

                string[] at = comando.Split(',');
                string msgAt = comando.Substring(6, at[0].Length - 6);
                serialPort2.WriteLine(msgAt);

                if (linux)
                {
                    textBox2.Text = serialPort2.ReadLine();
                }
                int tempo = 3000;
                if (comando.Contains("ANG"))
                {
                    tempo = 3000;
                }

                DateTime dateTimeTarget = DateTime.Now.AddMilliseconds(tempo);
                while (DateTime.Now < dateTimeTarget)
                {
                    System.Windows.Forms.Application.DoEvents();
                }

                if (!textBox2.Text.Contains(at[1]))
                {
                    textBox1.Text = "FALHA NO TESTE:  " + comando.Substring(6, at[0].Length - 6);
                    falha();
                }
                else
                {
                    timer1.Start();
                }
            }

            //checa serial number
            else if (comando == "cmdCSN")
            {
                if (snum == "") { falha(); }

            }

            //PRINT SERIAL NUMBER
            else if (comando == "cmdPSN")
            {
                textBox2.Text = "";
                timer1.Stop();
                if (!serialPort2.IsOpen)
                {
                    serialPort2.Open();
                }
                serialPort2.WriteLine("AT+SNUM");

                DateTime dateTimeTarget = DateTime.Now.AddMilliseconds(1000);
                while (DateTime.Now < dateTimeTarget)
                {
                    System.Windows.Forms.Application.DoEvents();
                }

                if (linux) { textBox2.Text = serialPort2.ReadLine(); }

                if (textBox2.Text.Contains("0x00"))
                {
                    string etq = textBox2.Text.Substring(textBox2.Text.Length - 6, 6);
                    textBox2.Text = etq;
                    printSn(etq);

                    MessageBox.Show(etq, "ETIQUETA");
                    timer1.Start();
                }
                else
                {
                    falha();
                }
            }


            else if (comando == "cmdCAD")
            {
                textBox2.Text = "";
                timer1.Stop();
                if (!serialPort2.IsOpen)
                {
                    serialPort2.Open();
                }
                serialPort2.WriteLine("AT+ADD");

                DateTime dateTimeTarget = DateTime.Now.AddMilliseconds(1000);
                while (DateTime.Now < dateTimeTarget)
                {
                    System.Windows.Forms.Application.DoEvents();
                }

                //LINUX
                if (linux) { textBox2.Text = serialPort2.ReadLine(); }

                if (!textBox2.Text.Contains(addr))
                {
                    falha();
                }
                else
                {
                    timer1.Start();
                }

            }

            else if (comando == "cmdCNW")
            {
                textBox2.Text = "";
                timer1.Stop();
                if (!serialPort2.IsOpen)
                {
                    serialPort2.Open();
                }
                serialPort2.WriteLine("AT+NW");

                DateTime dateTimeTarget = DateTime.Now.AddMilliseconds(1000);
                while (DateTime.Now < dateTimeTarget)
                {
                    System.Windows.Forms.Application.DoEvents();
                }

                //LINUX
                if (linux) { textBox2.Text = serialPort2.ReadLine(); }
                if (!textBox2.Text.Contains(channel))
                {
                    falha();
                }
                else
                {
                    timer1.Start();
                }

            }

            //*********************  MAC LOGIN *********************************

            else if (comando == "cmdMAC")
            {
                try
                {
                    timer1.Stop();

                    recebeFormSerial = "";
                    snum = "";
                    Serial sr = new Serial(this)
                    {
                        Text = "Etiqueta MAC"
                    };
                    sr.ShowDialog();
                    snum = recebeFormSerial;

                    mac = snum.Substring(0, 2) + "-";
                    mac += snum.Substring(2, 2) + "-";
                    mac += snum.Substring(4, 2) + "-";
                    mac += snum.Substring(6, 2) + "-";
                    mac += snum.Substring(8, 2) + "-";
                    mac += snum.Substring(10, 2);
                    timer1.Start();
                }
                catch (Exception)
                {
                    falha();
                }
            }
            //**************** READ MAC
            else if (comando == "cmdRMC")
            {
                timer1.Stop();
                cmdExec("getmac > mac.txt");
                Thread.Sleep(2000);

                StreamReader sr = new StreamReader("mac.txt");
                textBox2.Text = sr.ReadToEnd();
                sr.Close();

                if (!textBox2.Text.Contains(mac))
                {
                    falha();
                }
                else
                {
                    timer1.Start();
                }
            }

            //************** CHECK MEMORY ********************
            else if (comando.Contains("cmdMEM"))
            {
                string mem = comando.Substring(7, comando.Length - 7);
                textBox2.Text = mem;
                timer1.Stop();

                StreamReader sr = new StreamReader("system.txt");
                system = sr.ReadToEnd();
                sr.Close();

                if (!system.Contains(mem))
                {
                    falha();
                }
                else
                {
                    timer1.Start();
                }
            }

            //************** CHECK BLUETOOTH ********************
            else if (comando.Contains("cmdBTH"))
            {
                string bth = comando.Substring(7, comando.Length - 7);
                textBox2.Text = bth;
                timer1.Stop();

                StreamReader sr = new StreamReader("system.txt");
                system = sr.ReadToEnd();
                sr.Close();

                if (!system.Contains(bth))
                {
                    falha();
                }
                else
                {
                    timer1.Start();
                }
            }

            //************** CHECK BIOS ********************
            else if (comando.Contains("cmdBIOS"))
            {
                string bios = comando.Substring(8, comando.Length - 8);
                textBox2.Text = bios;
                timer1.Stop();

                StreamReader sr = new StreamReader("system.txt");
                system = sr.ReadToEnd();
                sr.Close();

                if (!system.Contains(bios))
                {
                    falha();
                }
                else
                {
                    timer1.Start();
                }
            }


            //************** CHECK PCI ********************
            else if (comando.Contains("cmdPCI"))
            {
                string PCI = comando.Substring(7, comando.Length - 7);
                textBox2.Text = PCI;
                timer1.Stop();

                StreamReader sr = new StreamReader("system.txt");
                system = sr.ReadToEnd();
                sr.Close();

                if (!system.Contains(PCI))
                {
                    falha();
                }
                else
                {
                    timer1.Start();
                }
            }

            //************** CHECK AUDIO ********************
            else if (comando.Contains("cmdAUDIO"))
            {
                timer1.Stop();
                string caminho = comando.Substring(9, comando.Length - 9);

                Process.Start("AUDIO.bat");
                Thread.Sleep(9000);



                if (File.Exists(caminho + "Fail.txt"))
                {
                    falha();
                }
                else
                {
                    timer1.Start();
                }
            }

            //************** CHECK ALERT ********************
            else if (comando.Contains("cmdALT"))
            {
                timer1.Stop();
                ALERT alert = new ALERT();
                alert.ShowDialog();
                timer1.Start();
            }

            //************** CHECK ODD ********************
            else if (comando.Contains("cmdODD") || comando.Contains("cmdSSD"))
            {
                string ODD = comando.Substring(7, comando.Length - 7);
                textBox2.Text = ODD;
                timer1.Stop();

                StreamReader sr = new StreamReader("ODD.txt");
                system = sr.ReadToEnd();
                sr.Close();

                if (!system.Contains(ODD))
                {
                    falha();
                }
                else
                {
                    timer1.Start();
                }
            }

            //**************** ETHERNET ************************
            else if (comando.Contains("cmdETH"))
            {

                try
                {
                    timer1.Stop();
                    Process.Start("eth.bat");
                    Thread.Sleep(3000);
                    string ping = comando.Substring(7, comando.Length - 7);

                    if (File.Exists(ping + "fail.txt"))
                    {
                        falha();
                    }
                    else
                    {
                        timer1.Start();
                    }

                }
                catch (Exception)
                {

                    falha();
                }

            }

            //************** CHECK BEEP ********************
            else if (comando.Contains("cmdBEEP"))
            {
                timer1.Stop();
                Process.Start("Beep.exe");
                DialogResult result = MessageBox.Show("O som do BEEP foi reproduzido?", "TESTE BEEP", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    timer1.Start();
                }
                else
                {
                    falha();
                }
            }

            //************** CHECK UNIDADE ********************
            else if (comando.Contains("cmdUSB"))
            {
                string usb = comando.Substring(7, comando.Length - 7);
                textBox2.Text = usb;
                if (Directory.Exists(usb) || File.Exists(usb))
                {
                    textBox1.ForeColor = Color.GreenYellow;
                    textBox1.Text += " OK!";
                }
                else
                {
                    falha();
                }
            }



            //GRAVA SERIAL NUMBER 1
            else if (comando == "cmdGSN1")
            {
                textBox2.Text = "";

                recebeFormSerial = "";
                snum = "";
                Serial sr = new Serial(this);
                sr.Text = "SERIAL NUMBER 1";
                sr.ShowDialog();
                snum = recebeFormSerial;

                if (snum.Length < 3) { fail = true; }
                else
                {
                    timer1.Start();
                }
            }

            //GRAVA SERIAL NUMBER 2
            else if (comando == "cmdGSN2")
            {
                textBox2.Text = "";

                recebeFormSerial = "";
                snum2 = "";
                Serial sr = new Serial(this);
                sr.Text = "SERIAL NUMBER 2";
                sr.ShowDialog();
                snum2 = recebeFormSerial;

                if (snum2.Length < 3) { fail2 = true; }
                else
                {
                    timer2.Start();
                }
            }
            //GRAVA CHANNEL
            else if (comando == "cmdCHN")
            {
                textBox2.Text = "";
                if (!serialPort2.IsOpen)
                {
                    serialPort2.Open();
                }

                timer1.Stop();
                recebeFormSerial = "";
                channel = "";
                Serial sr = new Serial(this);
                sr.Text = "CHANNEL";
                sr.ShowDialog();
                channel = recebeFormSerial;

                if (channel.Length > 0)
                {

                    int ch = int.Parse(channel);
                    channel = ch.ToString();

                    serialPort2.WriteLine("AT+NW=" + channel);

                    DateTime dateTimeTarget = DateTime.Now.AddMilliseconds(1000);
                    while (DateTime.Now < dateTimeTarget)
                    {
                        System.Windows.Forms.Application.DoEvents();
                    }

                    //LINUX
                    if (linux) { textBox2.Text = serialPort2.ReadLine(); }

                    if (textBox2.Text.Contains(channel) || textBox2.Text.Contains("OK"))
                    {
                        timer1.Start();
                    }
                    else
                    {
                        textBox1.Text = "FALHA NA GRAVAÇÃO DO NW";
                        falha();
                    }

                }
                else
                {
                    textBox1.Text = "FALHA NA GRAVAÇÃO DO NW";
                    falha();
                }
            }
            //GRAVA ADDRESS
            else if (comando == "cmdADD")
            {
                textBox2.Text = "";
                if (!serialPort2.IsOpen)
                {
                    serialPort2.Open();
                }


                timer1.Stop();
                recebeFormSerial = "";
                addr = "";
                Serial sr = new Serial(this);
                sr.Text = "ADDRESS";
                sr.ShowDialog();

                addr = recebeFormSerial;
                if (addr.Length > 0)
                {

                    int ad = int.Parse(addr);
                    addr = ad.ToString();

                    serialPort2.WriteLine("AT+ADD=" + addr);

                    DateTime dateTimeTarget = DateTime.Now.AddMilliseconds(1000);
                    while (DateTime.Now < dateTimeTarget)
                    {
                        System.Windows.Forms.Application.DoEvents();
                    }

                    //LINUX
                    if (linux) { textBox2.Text = serialPort2.ReadLine(); }

                    if (textBox2.Text.Contains("OK") || textBox2.Text.Contains(addr))
                    {
                        timer1.Start();
                    }
                    else
                    {
                        textBox1.Text = "FALHA NA GRAVAÇÃO DO ADDRESS";
                        falha();
                    }
                }
                else
                {
                    textBox1.Text = "FALHA NA GRAVAÇÃO DO ADDRESS";
                    falha();
                }
            }


            //PAUSA NO TESTE
            else if (comando.Contains("cmdDLY"))
            {
                timer1.Stop();
                try
                {
                    ms = int.Parse(comando.Substring(7, comando.Length - 7));
                    DateTime dateTimeTarget = DateTime.Now.AddMilliseconds(ms);
                    while (DateTime.Now < dateTimeTarget)
                    {
                        System.Windows.Forms.Application.DoEvents();
                    }
                    timer1.Start();
                }
                catch
                {
                    textBox1.Text = "FALHA NO COMANDO cmdDLY";
                    falha();
                }

            }


            //LER PORTA DIGITAL  [cmdRDR A0 0.00 0.00----------------------------
            else if (comando.Contains("RA") || comando.Contains("RB") || comando.Contains("RD") || comando.Contains("cmdRNG"))
            {
                textBox2.Text = "";
                analogRead(comando);
            }
            //READ VOLTAGE [ V,0.00,0.00
            else if (comando.Contains("cmdRVL"))
            {
                comando = comando.Substring(7, comando.Length - 7);

                analogRead(comando);
            }

            else if (comando.Contains("cmdCMD"))
            {
                comando = comando.Substring(7, comando.Length - 7);
                comandoTest = comando;

                serialPort1.Write(comando);
            }


            else if (comando.Contains("cmdREAD"))
            {
                string busca = comando.Substring(7, comando.Length - 1);
                MessageBox.Show(busca);
            }

            else if (comando.Contains("cmdUSB"))
            {
                Process.Start("usb.bat");

            }


            else if (comando.Contains("cmdFWV"))
            {
                serialPort1.WriteLine("SHOW");
            }


            //Read a file txt e get value
            else if (comando.Contains("cmdFILE"))
            {
                StreamReader sr = new StreamReader("usb.txt");
                string read = sr.ReadToEnd();
                sr.Close();
                //MessageBox.Show(read);
                string busca = comando.Substring(7, comando.Length - 7);
                if (!read.Contains(busca))
                {
                    textBox1.Text = "FALHA NA USB " + busca;
                    falha();
                }
            }
            // testRead = false;     
        }

        public void Await(int milliseconds, string comando)
        {
            serialPort1.Write(comando);

            DateTime dateTimeTarget = DateTime.Now.AddMilliseconds(milliseconds);
            while (DateTime.Now < dateTimeTarget)
            {
                System.Windows.Forms.Application.DoEvents();
            }

        }

        string msgRead = "";
        float v;

        private void analogRead(string comando)
        {
            if (!serialPort1.IsOpen) { serialPort1.Open(); }

            msgRead = comando;
            timer1.Stop();
            contaFalha++;
            textBox2.Text = "";
            str = comando.Split(',');
            float min = float.Parse(str[2]);
            float max = float.Parse(str[3]);

            serialPort1.WriteLine(str[1]);

            DateTime dateTimeTarget = DateTime.Now.AddMilliseconds(1000);
            while (DateTime.Now < dateTimeTarget)
            {
                System.Windows.Forms.Application.DoEvents();
            }


            //cmdRVL Tx, GAC,90,110
            //cmdRVL Tx, GVT,0.00,0.20
            //cmdRVL T5, GAP,0.00,0.08


            //LINUX
            if (linux) { textBox2.Text = serialPort1.ReadLine(); }

            try
            {



                /************   EXTRUCTURE FOR TESTS UNITS    ********************/
                if (str[1] == "TINP" || str[1] == "TINPF") { GAC = textBox2.Text; }
                if (str[1] == "VOUT" || str[1] == "TOL") { GVT = textBox2.Text; }
                if (str[1] == "OUTVPP") { GVT = textBox2.Text; }
                if (str[1] == "COUT" || str[1] == "COUT4F") { GAP = textBox2.Text; }
                if (str[1] == "GTR5") { GEF = textBox2.Text; }

                if (comandoTest == "TEST3") { test_100vac_4a = GAC + "Vac, " + GVT + " V, " + GAP + "amp"; }
                if (comandoTest == "TEST5") { test_efficiency = GEF + " %"; }
                if (comandoTest == "TOSC") { test_ripple = GVT + " Vpp"; }
                if (comandoTest == "TEST7" || comandoTest == "TESTF7") { test_overload = GAC + " Vac, " + GVT + " V, " + GAP + " A"; }
                if (comandoTest == "TEST8") { test_high_vac4a = GAC + " Vac, " + GVT + " V, " + GAP + " A"; }
                if (comandoTest == "TEST0") { test_high_vac0a = GAC + " Vac, " + GVT + " V, " + GAP + " A"; }
                if (comandoTest == "TEST9") { test_discharger = GAC + " Vac, " + GVT + " V"; }

                v = float.Parse("0" + textBox2.Text);
                Console.WriteLine(v.ToString());

                Console.WriteLine(comandoTest + " - " + test_100vac_4a);


                if (v >= min && v <= max)
                {
                    if (comandoTest == "TEST1") { testShortCurt = "PASS"; }

                    if (str[0] == "OUT")
                    {
                        serialPort1.WriteLine(str[0]);
                    }
                    else
                    {
                        serialPort1.WriteLine(str[0] + "PASS");
                    }

                    testRead = true;
                    timer1.Start();
                    contaFalha = 0;
                    reteste = false;
                }
                else
                {
                    if (contaFalha >= 5)
                    {
                        reteste = false;
                        falha();
                    }
                    else
                    {
                        reteste = true;
                        textBox2.Text = "";
                        contaFalha += 1;
                        contador = lineReteste - 1;
                        Console.WriteLine(contaFalha.ToString());
                        timer1.Start();
                    }
                }
            }
            catch (Exception)
            {
                contaFalha += 1;
                analogRead(msgRead);
            }
            string mm = "  [" + str[2] + " | " + textBox2.Text + " | " + str[3] + "] ";
            textBox1.Text = mm;

            if (contaFalha == 6)
            {
                falha();
            }
        }

        private void insertDataBase(int testNumber)
        {
            try
            {
                Console.WriteLine("Entrou no dataBase");
                conexao = new OleDbConnection(strcon);
                dbcmd = new OleDbCommand("INSERT INTO tabelaTestes(serial, data, OPERATOR, DURATION, status, CHECK_SHORT, 100VAC_60Hz, test_efficiency, OLP_100VAC, 0VAC_60Hz, DISCHARGER, 100VAC_60Hz_OP, 100VAC_60Hz_8125, EFC_230VAC_50Hz, 230VAC_50Hz, 264VAC_50Hz, 264VAC_50Hz_8125, SHORT_264VAC_47Hz, 230VAC_50Hz_3, 230VAC_50Hz_0, 0VAC_50Hz, DISCHARGER_END) VALUES(@serial, @data, @operador, @duracao, @status, @CHECK_SHORT, @100VAC_60Hz, @test_efficiency, @OLP_100VAC, @0VAC_60Hz, @DISCHARGER, @100VAC_60Hz_OP, @100VAC_60Hz_8125, @EFC_230VAC_50Hz, @230VAC_50Hz, @264VAC_50Hz, @264VAC_50Hz_8125, @SHORT_264VAC_47Hz, @230VAC_50Hz_3, @230VAC_50Hz_0, @0VAC_50Hz, @DISCHARGER_END)", conexao);

                if (testNumber == 1)
                {
                    dbcmd.Parameters.Add("@serial", OleDbType.VarChar).Value = snum;
                    dbcmd.Parameters.Add("@data", OleDbType.VarChar).Value = DateTime.Now.ToString();
                    dbcmd.Parameters.Add("@operador", OleDbType.VarChar).Value = textBox4.Text;
                    dbcmd.Parameters.Add("@duracao", OleDbType.VarChar).Value = fim.ToString();
                    dbcmd.Parameters.Add("@status", OleDbType.VarChar).Value = testStatus;
                }

                if (testNumber == 2)
                {
                    dbcmd.Parameters.Add("@serial", OleDbType.VarChar).Value = snum2;
                    dbcmd.Parameters.Add("@data", OleDbType.VarChar).Value = DateTime.Now.ToString();
                    dbcmd.Parameters.Add("@operador", OleDbType.VarChar).Value = textBox4.Text;
                    dbcmd.Parameters.Add("@duracao", OleDbType.VarChar).Value = fim2.ToString();
                    dbcmd.Parameters.Add("@status", OleDbType.VarChar).Value = testStatus2;
                }

                dbcmd.Parameters.Add("@CHECK_SHORT", OleDbType.VarChar).Value = TESTS[testNumber, 0];
                dbcmd.Parameters.Add("@100VAC_60Hz", OleDbType.VarChar).Value = TESTS[testNumber, 1];
                dbcmd.Parameters.Add("@test_efficiency", OleDbType.VarChar).Value = TESTS[testNumber, 2];
                dbcmd.Parameters.Add("@OLP_100VAC", OleDbType.VarChar).Value = TESTS[testNumber, 3];
                dbcmd.Parameters.Add("@0VAC_60Hz", OleDbType.VarChar).Value = TESTS[testNumber, 4];
                dbcmd.Parameters.Add("@DISCHARGER", OleDbType.VarChar).Value = TESTS[testNumber, 5];
                dbcmd.Parameters.Add("@100VAC_60Hz_OP", OleDbType.VarChar).Value = TESTS[testNumber, 6];

                dbcmd.Parameters.Add("@100VAC_60Hz_8125", OleDbType.VarChar).Value = TESTS[testNumber, 7];
                dbcmd.Parameters.Add("@EFC_230VAC_50Hz", OleDbType.VarChar).Value = TESTS[testNumber, 8];
                dbcmd.Parameters.Add("@230VAC_50Hz", OleDbType.VarChar).Value = TESTS[testNumber, 9];
                dbcmd.Parameters.Add("@264VAC_50Hz", OleDbType.VarChar).Value = TESTS[testNumber, 10];

                dbcmd.Parameters.Add("@264VAC_50Hz_8125", OleDbType.VarChar).Value = TESTS[testNumber, 11];
                dbcmd.Parameters.Add("@SHORT_264VAC_47Hz", OleDbType.VarChar).Value = TESTS[testNumber, 12];
                dbcmd.Parameters.Add("@230VAC_50Hz_3", OleDbType.VarChar).Value = TESTS[testNumber, 13];
                dbcmd.Parameters.Add("@230VAC_50Hz_0", OleDbType.VarChar).Value = TESTS[testNumber, 14];

                dbcmd.Parameters.Add("@0VAC_50Hz", OleDbType.VarChar).Value = TESTS[testNumber, 15];
                dbcmd.Parameters.Add("@DISCHARGER_END", OleDbType.VarChar).Value = TESTS[testNumber, 16];

                conexao.Open();
                dbcmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conexao.Close();
            }
        }

        private void clearValuesDb(int position)
        {
            dbcmd.Parameters.Clear();
            for (int i = 0; i < 17; i++)
            {
                TESTS[position, i] = "NULL";
            }

        }

        public void FIM()
        {
            try
            {
                timer1.Stop();
                testStatus = "PASS";
                inicio = false;

                if (trackingTest)
                {
                    if (_mode == "ACCDB")
                    {
                        insertDataBase(1);
                        clearValuesDb(1);
                    }
                    if (_mode == "txt")
                    {
                        createLogs(1);
                    }
                }

                textBox1.ForeColor = Color.GreenYellow;
                textBox1.Text = "FIM";
                richTextBox2.Text += contaTeste.ToString() + " - " + validaTeste + "\t[PASS]\r\n";
                testStatus = "FAIL";
                textBox1.Text = fim.ToString();



            }
            catch (Exception)
            {

                //MessageBox.Show(ex.ToString());
            }

        }

        string testStatus2 = "FAIL";
        public void FIM2()
        {

            try
            {
                endTimer2();
                timer2.Stop();
                testStatus2 = "PASS";
                inicio2 = false;

                if (trackingTest)
                {
                    if (_mode == "ACCDB")
                    {
                        insertDataBase(2);
                        clearValuesDb(2);
                    }
                    if (_mode == "txt")
                    {
                        createLogs(2);
                    }
                }


                testStatus2 = "FAIL";
                textBox1.Text = fim2.ToString();

            }
            catch (Exception)
            {

                //MessageBox.Show(ex.ToString());
            }

        }

        public string msgFail = "";
        public void falha()
        {
            if (serialPort1.IsOpen)
            {
                Console.WriteLine("TURNOFF");
                serialPort1.WriteLine("CHAING");
                serialPort1.WriteLine("TURNOFF");

            }
            if (snum.Length > 2)
            {
                snum = "";
                endTimer();
            }
            serialPort2.Close();
            Thread.Sleep(200);
            textBox1.BackColor = Color.Red;
            timer1.Stop();
            msgFail = textBox1.Text;
            richTextBox2.Text += contaTeste.ToString() + " - " + validaTeste + "\t[FAIL]\r\n";
            FAIL fim = new FAIL(this);
        }

        public void inicioTeste()
        {
            try
            {
                contaTeste = 1;
                contaFalhaTP = 0;
                if (!serialPort1.IsOpen)
                {
                    serialPort1.Open();
                }

                if (trackingTest)
                {
                    parametro("cmdGSN1");
                }
                else
                {
                    timer1.Start();

                }


            }
            catch (Exception)
            {
                fail = true;
                textBox6.BackColor = Color.Red;
                textBox6.Text = "SERIAL PORT FAIL";
                textBox6.Visible = true;
            }
        }

        public void inicioTeste2()
        {
            try
            {
                if (!serialPort2.IsOpen)
                {
                    serialPort2.Open();
                }

                if (trackingTest)
                {
                    parametro("cmdGSN2");
                }
                else
                {
                    timer2.Start();
                }
            }
            catch (Exception)
            {
                fail2 = true;
            }
        }

        private String _tempo;
        public String tempo
        {
            get { return _tempo; }
            set { _tempo = contador.ToString(); }
        }

        private void simulatorToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        string rxData;
        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (!linux)
            {
                rxData = serialPort1.ReadExisting();
                this.Invoke(new EventHandler(dataReceived));
            }
        }

        private void dataReceived(object sender, EventArgs e)
        {
            textBox2.AppendText(rxData);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string[] lines = System.IO.File.ReadAllLines("teste.txt");

            foreach (string line in lines)
            {
                // Use a tab to indent each line of the file.
                if (line.Contains("RA00"))
                {
                    textBox1.Text = line;
                }

            }
        }


        bool getSerial2;
        private void timer2_Tick(object sender, EventArgs e)
        {
            if (fail2 == false)
            {
                if (inicio2 == false)
                {
                    //inicia temporizador de teste
                    initTimer2();
                    inicio2 = true;
                }

                if (getSerial2)
                {
                    //parametro("cmdGSN");
                    TEST2[0] = true;
                    serialPort2.Write("0");
                    getSerial2 = false;
                }

                if (TEST2[indexTest2])
                {
                    TEST2[indexTest2] = false;
                    RES_TEST2[indexTest2] = true;
                }

                if (RES_TEST2[indexTest2])
                {
                    textBox8.Text = rxData2;
                    if (textBox8.Text.Contains("X"))
                    {
                        string[] dados = textBox8.Text.Split(';');
                        if (dados[0] == "1")
                        {
                            statusTest2 = "PASS";
                        }
                        else
                        {
                            statusTest2 = "FAIL";
                        }

                        RES_TEST2[indexTest2] = false;
                        rxData2 = "";
                        textBox8.Text = "";

                        if (dados[0] == "1")
                        {
                            //TESTE CURTO CIRCUITO
                            if (indexTest2 == 0) { TESTS[2, indexTest2] = "PASS"; }
                            else if (indexTest2 == 2 || indexTest2 == 8) { TESTS[2, indexTest2] = dados[2]; }   //TEST EFICIENCIA 100 e 230AC
                            else
                            {
                                TESTS[2, indexTest2] = dados[1] + "VAC, " + dados[2] + "VDC, " + dados[3] + "A";
                            }

                            indexTest2++;
                            TEST2[indexTest2] = true;
                            dados[0] = "";
                            serialPort2.Write(indexTest2.ToString());
                        }
                        else
                        {
                            //TESTE CURTO CIRCUITO
                            if (indexTest2 == 0) { TESTS[2, indexTest] = "FAIL"; }
                            else if (indexTest2 == 2 || indexTest2 == 8) { TESTS[2, indexTest2] = dados[2]; }   //TEST EFICIENCIA 100 e 230AC
                            else
                            {
                                TESTS[2, indexTest2] = dados[1] + "VAC, " + dados[2] + "VDC, " + dados[3] + "A";
                            }

                            timer2.Stop();
                            inicio2 = false;

                            if (trackingTest)
                            {
                                insertDataBase(2);
                                clearValuesDb(2);
                            }

                        }

                    }
                }

                if (indexTest2 > 16)
                {
                    FIM2();
                }

            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (Directory.Exists("/home/"))
            {
                string[] lines = System.IO.File.ReadAllLines(caminho);
                string local = "";
                foreach (string line in lines)
                {
                    // Use a tab to indent each line of the file.
                    string[] str = line.Split('=');
                    if (str[0] == "script") { local = str[1]; }
                }

                StreamWriter sw = new StreamWriter(local);
                sw.WriteLine(richTextBox1.Text);
                sw.Close();

                MessageBox.Show("Salvo com sucesso!!");
            }
            else
            {
                try
                {
                    StreamWriter sw = new StreamWriter("teste.txt");
                    sw.Write(richTextBox1.Text);
                    sw.Close();
                    checkBox1.Checked = false;
                    MessageBox.Show("DATA SAVED SUCESSFULLY!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

            }
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (linux)
            {
                Process.Start(System.Windows.Forms.Application.StartupPath.ToString() + "/readme.txt");
            }
            else
            {
                Process.Start(System.Windows.Forms.Application.StartupPath.ToString() + "\\readme.txt");
            }
        }



        private void button3_Click(object sender, EventArgs e)
        {
            //BaseBarcode barcode = BarcodeFactory.GetBarcode(Symbology.Code128);
            //barcode.Number = textBox1.Text;

            //barcode.ForeColor = Color.Black;

            //Bitmap bitmap = barcode.Render();
            //picBarcode.Image = bitmap;

            //rect = new System.Drawing.Rectangle(0, 40, picBarcode.Image.Width - 2, picBarcode.Image.Height - 40);
            //cropped = bitmap.Clone(rect, bitmap.PixelFormat);
            //picBarcode.Image = cropped;

            //// You can also save it to file:

            //barcode.Save("D:\\barcode.gif", ImageType.Gif);
        }

        public void imprimir(object o, PrintPageEventArgs e)
        {
            System.Drawing.Image i = picBarcode.Image;
            //local de impressão 50 x, 50 y.
            e.Graphics.DrawImage(i, 70, 50);
        }


        private void printSn(string str)
        {
            //BaseBarcode barcode = BarcodeFactory.GetBarcode(Symbology.Code128);
            //barcode.Number = textBox2.Text;

            //barcode.ForeColor = Color.Black;

            //Bitmap bitmap = barcode.Render();
            //picBarcode.Image = bitmap;

            //rect = new System.Drawing.Rectangle(0, 40, picBarcode.Image.Width - 2, picBarcode.Image.Height - 40);
            //cropped = bitmap.Clone(rect, bitmap.PixelFormat);
            //picBarcode.Image = cropped;
        }


        private void pd_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs ev)
        {
            CreateEan13();
            ean13.Scale = (float)Convert.ToDecimal("0,8");
            ean13.DrawEan13Barcode(ev.Graphics, new System.Drawing.Point(0, 0));
            // Add Code here to print other information.
            ev.Graphics.Dispose();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void serialPort2_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            rxData2 = serialPort2.ReadExisting();
            this.Invoke(new EventHandler(dataReceived2));
        }

        TimeSpan dtIni;
        private void initTimer()
        {
            dtIni = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
        }

        TimeSpan dtIni2;
        private void initTimer2()
        {
            dtIni2 = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
        }

        private void initTest2()
        {
            clearDataGrid2();
            timer2.Stop();
            rxData2 = "";
            getSerial2 = true;
            inicio2 = false;
            fail2 = false;
            indexTest2 = 0;
            textBox8.Text = "";
            inicioTeste2();

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            initTest2();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.D1)
            {
                initTest1();
            }

            if (e.KeyCode == Keys.D2)
            {
                initTest2();
            }

        }

        public TimeSpan fim;

        private void button4_Click_3(object sender, EventArgs e)
        {
            //
        }

        private void button4_Click_4(object sender, EventArgs e)
        {
            LancamentoOP chamaLCT = new LancamentoOP();
            chamaLCT.ShowDialog();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            //DialogResult result = MessageBox.Show("Se estiver tudo pronto, clique em 'OK' para inicializar o processo (USE O LEITOR PARA DAR O OK, POSICIONE NO QRCode/CÓDBarra e dê o clique).", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //if (result == DialogResult.OK)
            //{
            //    SendKeys.SendWait("{ENTER}");
            //}

            //button1.Focus();
        }

        private void endTimer()
        {
            TimeSpan dtFim = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
            fim = dtFim.Subtract(dtIni);
        }

        int contaenvio = 0;
        bool sendDataServer = false;
        private void timer3_Tick(object sender, EventArgs e)
        {
            textBox2.Text = rxData;
            if (textBox2.Text.Contains("start"))
            {
                textBox2.Text = "";
                initTest1();

            }

            if (textBox2.Text.Contains("EMERG ON"))
            {
                textBox2.Text = "";
                frmEmergencia emergencia = new frmEmergencia(this);
                instanciaEmerg = true;
                emergencia.ShowDialog();
            }

            if (textBox2.Text.Contains("EMERG OFF"))
            {
                instanciaEmerg = false;
                textBox2.Text = "";
            }
        }

        public void sendData(string data)
        {
            if (socket.Connected)
            {
                try
                {
                    socket.Send(Encoding.ASCII.GetBytes(data));
                }
                catch (SocketException e)
                {
                    MessageBox.Show(e.Message);
                    socket.Close();
                    return;
                }
            }
            else
            {
                MessageBox.Show("Dispositivo Offline", "Erro de comunicação", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen) { serialPort1.Close(); }
            Config cfg = new Config();
            cfg.ShowDialog();
        }

        private void button4_Click_2(object sender, EventArgs e)
        {
            sendData(textBox4.Text);
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        public TimeSpan fim2;
        private void endTimer2()
        {
            TimeSpan dtFim = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
            fim2 = dtFim.Subtract(dtIni2);
        }

        public TimeSpan endCicle;
        private void endCicleTimer()
        {
            TimeSpan _endCicle = new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
            endCicle = _endCicle.Subtract(dtIni);

            cicliTimerStr = endCicle.ToString();
            Console.WriteLine("Cicle Timer: " + endCicle);
        }

        private void button4_Click(object sender, EventArgs e)
        {


        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void simulatorToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Config cf = new Config();
            cf.ShowDialog();
        }

        private void setupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Setup st = new Setup();
            st.ShowDialog();
        }

        private void dataTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataTest dt = new dataTest();
            dt.ShowDialog();
        }

        private void dataReceived2(object sender, EventArgs e)
        {
            textBox8.AppendText(rxData2);
        }

        private void configToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        public static Bitmap MakeGrayscale3(Bitmap original)
        {
            //create a blank bitmap the same size as original
            Bitmap newBitmap = new Bitmap(original.Width, original.Height);

            //get a graphics object from the new image
            using (Graphics g = Graphics.FromImage(newBitmap))
            {
                //create the grayscale ColorMatrix
                ColorMatrix colorMatrix = new ColorMatrix(
                new float[][]
                {
                  new float[] {.3f, .3f, .3f, 0, 0},
                  new float[] {.59f, .59f, .59f, 0, 0},
                  new float[] {.11f, .11f, .11f, 0, 0},
                  new float[] {0, 0, 0, 1, 0},
                  new float[] {0, 0, 0, 0, 1}
                });

                //create some image attributes
                using (ImageAttributes attributes = new ImageAttributes())
                {

                    //set the color matrix attribute
                    attributes.SetColorMatrix(colorMatrix);

                    //draw the original image on the new image
                    //using the grayscale color matrix
                    g.DrawImage(original, new System.Drawing.Rectangle(0, 0, original.Width, original.Height),
                                0, 0, original.Width, original.Height, GraphicsUnit.Pixel, attributes);
                }
            }
            return newBitmap;
        }

        string serialRead = "";
        private void createLogs(int testNumber)
        {
            try
            {
                //SE NÃO EXISTE DIRETORIO DATALOG, CRIA 1
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                //SE NÃO EXISTE DIRETORIO DATA DE HOJE, CRIA 1
                string namePath = snum;
                string msg = "";

                if (testNumber == 1)
                {
                    msg = snum
                        + ";Data:" + DateTime.Now
                        + ";User:" + textBox4.Text
                        + ";Timer:" + fim.ToString()
                        + ";Status:" + testStatus;

                    serialRead = snum;
                }

                msg += ";LIGA_127V[" + TESTS[testNumber, 0] + "]"
                     + ";CORRENTE_1[" + TESTS[testNumber, 1] + "]"
                     + ";POTENCIA_1[" + TESTS[testNumber, 2] + "]"
                     + ";TEMPERATURA_1[" + TESTS[testNumber, 3] + "]"

                     + ";LED_+[" + TESTS[testNumber, 5] + "]"
                     + ";CORRENTE_2[" + TESTS[testNumber, 6] + "]"
                     + ";POTENCIA_2[" + TESTS[testNumber, 7] + "]"

                     + ";LED_-[" + TESTS[testNumber, 8] + "]"
                     + ";TEMPERATURA_2:[" + TESTS[testNumber, 9] + "]\n";


                using (StreamWriter writer = new StreamWriter(directory + namePath + ".txt", true))
                {
                    writer.WriteLine(msg);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
        }
    }



}
