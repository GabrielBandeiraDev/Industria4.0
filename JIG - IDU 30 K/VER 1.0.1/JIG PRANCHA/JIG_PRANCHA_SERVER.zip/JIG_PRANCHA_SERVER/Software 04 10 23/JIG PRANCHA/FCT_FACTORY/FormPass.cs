﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FCT_FACTORY
{
    public partial class FormPass : Form
    {
        Form1 form1;
        public FormPass(Form1 fm1)
        {
            this.StartPosition = FormStartPosition.CenterScreen;
            InitializeComponent();
            form1 = fm1;
        }


        private void FormPass_Load(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            label2.Text = "Test Time: " + form1.fim;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Process.Start("shutdown.bat");
            this.Close();
        }
    }
}
